const { Router } = require('express');
const moment = require('moment-timezone');
const router = Router();

router.get('/server-time-offset', (req, res) => {
  const serverNow = moment.tz('Asia/Seoul').toDate();
  const clientNow = moment.tz(req.query.now, 'Asia/Seoul').toDate();
  res.json({
    offset: moment.duration(moment(serverNow).diff(moment(clientNow))).asSeconds(),
    server: serverNow,
    client: clientNow,
  });
});

module.exports = router;