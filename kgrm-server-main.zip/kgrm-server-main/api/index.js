const { Router } = require('express');
const router = Router();

// router.use('/admin', require('./admin'));
router.use('/user', require('./user'));
router.use(require('./util'));

module.exports = router;