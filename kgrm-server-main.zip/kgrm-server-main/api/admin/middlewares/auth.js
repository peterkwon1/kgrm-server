const jwt = require('../../../helpers/jwt');
const { Administrator } = require('../../../models');

module.exports = async (req, res, next) => {
  let token = req.headers["authorization"];
  if (!token) 
    return res.status(401).json({ message: '토큰값이 유효하지 않습니다.' });
  if (token.indexOf('Bearer ') === 0) token = token.slice(7);
  try {
    const decoded = await jwt.verify(token);
    if (!decoded) 
      return res.status(403).json({ message: '권한이 없습니다.' });
    const admin = await Administrator.findById(decoded._id);
    if (!admin)
      return res.status(403).json({ message: '권한이 없습니다.' });
    req.user = decoded;
    return next();
  }
  catch(err) {
    return res.status(401).json({ message: '로그인 정보가 올바르지 않습니다.' });
  }
}