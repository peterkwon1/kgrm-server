const { Router } = require('express');
const router = Router();
const bcrypt = require('../../helpers/bcrypt');
const jwt = require('../../helpers/jwt');
const { Member } = require('../../models');
const auth = require('./middlewares/auth');

router.post('/join', async (req, res) => {
    try {
        const { memId, memPassword, memNickname, memName, memMobile, memBirth, memRole } = req.body;
        const m = await Member.findOne({ memId });

        if (m !== null) {
            return res.status(400).json({ message: '이미 존재하는 이메일입니다.' });
        } else {
            req.body.memPassword = await bcrypt.hash(memPassword);

            const member = new Member({ ...req.body });
            await member.save();

            console.log('save end');
            res.json(member);
        }

    } catch (e) {
        if(e.response) console.log(e.response.data.message);
    }
})

module.exports = router;