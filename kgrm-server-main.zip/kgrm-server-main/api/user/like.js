const { Router } = require('express');
const router = Router();
const auth = require('./middlewares/auth');
const { Like } = require('../../models');

router.get('/get/like', async (req, res) => {
    const { rid, uid } = req.query;
    const like = await Like.findOne({ member: uid, room: rid });

    res.json(like);
})

router.post('/post/like', async (req, res) => {
    const { rid, uid } = req.body;

    const like = new Like({ member: uid, room: rid });

    await like.save();
    res.json(like);
})

router.delete('/delete/like', async (req, res) => {
    const { rid, uid } = req.query;
    const like = await Like.findOne({ member: uid, room: rid });

    await like.remove();

    res.status(202).end();
})

router.get('/my/likes', async (req, res) => {
    const { uid } = req.query;
    const likes = await Like.find({ member: uid })
        .populate('room');

    res.json(likes);
})

module.exports = router;