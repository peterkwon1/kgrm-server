const { Router } = require('express');
const router = Router();
const bcrypt = require('../../helpers/bcrypt');
const jwt = require('../../helpers/jwt');
const { Member } = require('../../models');

router.post('/login', async (req, res) => {
    const { memId, memPassword } = req.body;

    const m = await Member.findOne({ memId: memId });
    if (!m) return res.status(400).json({ message: '존재하지 않는 이메일입니다.' });

    const p = await bcrypt.compare(memPassword, m.memPassword);
    if (p === false) return res.status(400).json({ message: '비밀번호를 확인해주세요.' });

    res.status(200).json({ token: await jwt.sign({ _id: m._id }), uid: m._id });
})

module.exports = router;