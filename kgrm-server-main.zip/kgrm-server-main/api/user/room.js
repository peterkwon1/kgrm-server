const { Router } = require('express');
const router = Router();
const { Room } = require('../../models');
const auth = require('./middlewares/auth');

router.post('/add/room', async (req, res) => {
    const room = new Room({ ...req.body });
    await room.save();

    res.json(room);
})

router.get('/list/room', async (req, res) => {
    const rooms = await Room.find({});

    res.json(rooms);
})

router.get('/room/:id', async (req, res) => {
    try {
        const room = await Room.findById(req.params.id)
            .populate('roomMember');

        console.log('server')
        res.json(room);
    } catch (e) {
        if (e.response) console.log(e.response.data.message);
    }
})

module.exports = router;