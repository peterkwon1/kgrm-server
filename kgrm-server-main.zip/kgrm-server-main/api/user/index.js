const { Router } = require('express');
const router = Router();

router.use(require('./join'));
router.use(require('./login'));
router.use(require('./room'));
router.use(require('./upload'));
router.use(require('./like'));

module.exports = router;