const bcrypt = require('bcryptjs');
const SALT = 10;

module.exports = {
  async hash(data) {
    return new Promise((resolve, reject) => {
      bcrypt.hash(data, SALT, (err, hash) => {
        if (err) return reject(err);
        return resolve(hash);
      })
    });
  },

  async compare(input, data) {
    return new Promise((resolve, reject) => {
      bcrypt.compare(input, data, (err, flag) => {
        if (err) return reject(err);
        return resolve(flag);
      })
    })
  }
}