const aws = require('aws-sdk');

const s3 = new aws.S3({
    accessKeyId: 'AKIAXA4INNUSAP6T57IH',
    secretAccessKey: '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',
    region: 'ap-northeast-2',
})

module.exports = s3;