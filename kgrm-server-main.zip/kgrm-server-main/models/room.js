const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const RoomSchema = new Schema({
    // roomIdx: { type: String, unique: true }, // 방 인덱스
    roomAddr1: { type: String, required: true }, // 방 주소
    roomAddr2: { type: String }, // 방 상세 주소
    roomSiDo: { type: String, required: true }, // 방 시, 도
    roomSiGunGu: { type: String, required: true }, // 방 시, 군, 구
    roomEupMyeonDong: { type: String, required: true }, // 방 읍, 면, 동
    roomLat: { type: Number }, // 방 위도
    roomLng: { type: Number }, // 방 경도
    roomHostMobile: { type: String }, // 방 집주인 전화번호
    roomLandArea: { type: Number, required: true }, // 방 대지면적
    roomGrossFloorArea: { type: Number, required: true }, // 방 연면적
    roomJimok: { type: String },
    roomBuildingUsage: { type: String },
    roomBuildingStructure: { type: String },
    roomConfirmedAt: { type: Date, required: true }, // 방 승인날짜
    roomTotalLoan: { type: Number, default: 0 }, // 방 대출총액
    roomTotalDeposit: { type: Number, default: 0 }, // 방 보증금총액
    roomThumbnailImg: { type: String, required: true }, // 방 대표 이미지
    roomImg: { type: String, required: true }, // 방 이미지
    roomDoorImg: { type: String, required: true }, // 방 현관 이미지
    roomBathroomImg: { type: String, required: true }, // 방 욕실 이미지
    roomOptionalImg1: { type: String, default: undefined }, // 방 옵션 이미지 1
    roomOptionalImg2: { type: String, default: undefined }, // 방 옵션 이미지 2
    roomOptionalImg3: { type: String, default: undefined }, // 방 옵션 이미지 3
    roomOptionalImg4: { type: String, default: undefined }, // 방 옵션 이미지 4
    roomContractType: { type: String, enum: ['월세', '전세'], default: '월세', required: true }, // 방 계약 유형
    roomDeposit: { type: Number, default: 1, required: true }, // 방 보증금
    roomMonthlyPrice: { type: Number, default: 0 }, // 방 월세
    roomManageFee: { type: Number, default: 0 }, // 방 관리비
    roomManageOptions: { type: [String] }, // 방 관리비 포함 항목
    roomAvailableAt: { type: String, required: true }, // 방 입주 가능일
    roomHouseType: { type: String, enum: ['빌라형', '오피스텔형', '단독형'], default: '빌라형' }, // 방 집 형태
    roomType: { type: String, enum: ['오픈형 원룸', '분리형 원룸', '복층형 원룸'], default: '오픈형 원룸' }, // 방 형태
    roomTotalFloor: { type: String, required: true }, // 방 총 층수
    roomFloor: { type: String, required: true }, // 방 층수
    roomDirection: { type: String, enum: ['남향', '남동향', '동향', '북동향', '북향', '북서향', '서향', '남서향'], default: '남향' }, // 방 방향
    roomArea: { type: Number, default: 1 }, // 방 면적
    roomBasicOptions: { type: [String] }, // 방 기본 옵션
    roomIsFullOption: { type: Boolean, default: false }, // 방 풀옵션 여부
    roomBasicOptionsMemo: { type: String }, // 방 기본 옵션 메모
    roomCanParking: { type: Boolean, default: false }, // 방 주차 가능 여부
    roomParkingCount: { type: Number, default: 0 }, // 방 주차 가능 수
    roomExistEv: { type: Boolean, default: false }, // 방 엘리베이터 유무
    roomExistVeranda: { type: Boolean, default: false }, // 방 베란다 유무
    roomExistStorage: { type: Boolean, default: false }, // 방 창고 유무
    roomFacilityMemo: { type: String }, // 방 시설 메모
    roomCanPapering: { type: Boolean, default: false }, // 방 장판 가능 여부
    roomCanFloor: { type: Boolean, default: false }, // 방 도배 가능 여부
    roomCanLoan: { type: Boolean, default: false }, // 방 대출 가능 여부
    roomLoanMemo: { type: String }, // 방 대출 메모
    roomCanPet: { type: Boolean, default: false }, // 방 반려동물 가능 여부
    roomPetOptions: { type: [String] }, // 방 반려동물 옵션
    roomPetMemo: { type: String }, // 방 반려동물 메모
    roomMemo: { type: String }, // 방 메모
    roomStatus: { type: String, enum: ['승인대기', '등록완료', '계약완료'], default: '승인대기' }, // 방 상태
    roomHide: { type: Boolean, default: false }, // 방 숨김 여부
    roomMember: { type: Schema.Types.ObjectId, ref: 'Member' }, // 방 등록 회원
    deleteFlag: { type: Boolean, default: false }, // 방 삭제 여부
    deleteAt: { type: Date } // 방 삭제일
}, { timestamps: true });

module.exports = mongoose.model('Room', RoomSchema);