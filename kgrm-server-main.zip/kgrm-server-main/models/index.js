module.exports = {
    Member: require('./member'), // 회원 테이블
    Room: require('./room'), // 방 테이블
    Like: require('./like'),
    RecentView: require('./recent-view'),
    Order: require('./order')
};