const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const MemberSchema = new Schema({
    memId: { type: String, unique: true, required: true }, // 회원 아이디
    memPassword: { type: String, required: true }, // 회원 비밀번호
    memProvider: { type: String, default: 'form' }, // 회원가입 유형
    memName: { type: String, required: true }, // 회원 이름
    memMobile: { type: String, unique: true, required: true }, // 회원 전화번호
    memNickname: { type: String }, // 회원 별명
    memRole: { type: String, enum: ['user', 'host'], default: 'user' }, // 회원 유형 (권한)
    memPushIsOk: { type: Boolean, default: true }, // 회원 푸시 알림 수신 동의 여부
    memNightIsOk: { type: Boolean, default: false }, // 회원 야간 푸시 알림 수신 동의 여부
    memSmsIsOk: { type: Boolean, default: false }, // 회원 sms 마케팅 정보 수신 동의 여부
    memEmailIsOk: { type: Boolean, default: false }, // 회원 email 마케팅 정보 수신 동의 여부
    memIsSleep: { type: Boolean, default: false }, // 회원 휴면 여부
    memOutAvailable: { type: Boolean, default: true }, // 회원 탈퇴 가능 여부
    memBirth: { type: String }, // 회원 생년월일
    memProfileImage: { type: String }, // 회원 프로필 이미지
    memLastLoginAt: { type: Date }, // 회원 마지막 로그인 날짜
    memLastPwUpdateAt: { type: Date }, // 회원 마지막 비밀번호 수정 날짜
    deleteFlag: { type: Boolean, default: false }, // 회원 탈퇴 여부
    deleteAt: { type: Date } // 회원 탈퇴일
}, { timestamps: true });

module.exports = mongoose.model('Member', MemberSchema);

