const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const LikeSchema = new Schema({
    member: { type: Schema.Types.ObjectId, ref: 'Member'},
    room: { type: Schema.Types.ObjectId, ref: 'Room' },
}, { timestamps: true });

module.exports = mongoose.model('Like', LikeSchema)