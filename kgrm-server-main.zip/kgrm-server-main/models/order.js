const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const OrderSchema = new Schema({
    orderIdx: { type: String, unique: true, required: true },
    orderContractType: { type: String, enum: ['월세', '전세'], default: '월세' },
    orderAvailableAt: { type: Date },
    orderFinalAt: { type: Date },
    orderCanParking: { type: Boolean, default: false },
    orderCanPet: { type: Boolean, default: false },
    orderCanLoan: { type: Boolean, default: false },
    orderAddr1: { type: String },
    orderSiDo: { type: String },
    orderSiGunGu: { type: String },
    orderEupMyeonDong: { type: String },
    orderLat: { type: String },
    orderLng: { type: String },
    orderRadius: { type: Number },
    orderDeposit: { type: Number },
    orderMonthlyPrice: { type: Number },
    orderRoomArea: { type: [String] },
    orderRoomType: { type: [String] },
    orderFloor: { type: [String] },
    orderImportantOption: { type: String },
    orderRequest: { type: String },
    orderContactTime: { type: String },
    orderStatus: { type: String },
    orderCheckedAt: { type: Date },
    orderMatchedAt: { type: Date },
    orderCanceledAt: { type: Date },
    orderMember: { type: Schema.Types.ObjectId, ref: 'Member' },
    tempSaveFlag: { type: Boolean, default: false }, // 임시 저장 여부
    deleteFlag: { type: Boolean, default: false }, // 주문 삭제 여부
    deleteAt: { type: Date } // 주문 삭제일
}, { timestamps: true });

module.exports = mongoose.model('Order', OrderSchema);